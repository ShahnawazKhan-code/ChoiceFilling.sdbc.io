import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  formGroup: FormGroup = new FormGroup({
    nameOfOrganization: new FormControl(''),
    // contactNumber: new FormControl(''),
    // email: new FormControl(''),
    // dateOfRegistration: new FormControl(''),
    // testOrg: new FormControl(''),
    // orgSidebar: new FormControl(''),
});
submitted: boolean = false;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
 this.form();
  
    }
    form() {
      this.formGroup = this.formBuilder.group({
        // typeOfOrganization: ['', [Validators.required]],
        nameOfOrganization: ['',[Validators.required]],
        // contactNumber: ['',Validators.compose([Validators.required, Validators.pattern("[0-9]{10}")])],
        // email: ['', Validators.compose([Validators.required, Validators.pattern(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)])],
        // dateOfRegistration: ['', [Validators.required]],
        // testOrg: [false],
        // orgSidebar: [false]
      });
    }
    get f() { return this.formGroup.controls; }

}
